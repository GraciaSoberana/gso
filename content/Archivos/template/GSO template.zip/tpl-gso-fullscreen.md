<% content %>

<grid drag="14 8" drop="83 90">
<img src="plain_logo_GSO.svg" style="width:100%;opacity:0.75;" />
</grid>

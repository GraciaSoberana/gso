import os

folder_path = '.'  # Esto indica que la carpeta es la actual

# Recorre todos los archivos en la carpeta
for filename in os.listdir(folder_path):
    if filename.endswith('.md'):
        file_path = os.path.join(folder_path, filename)
        
        # Lee el contenido del archivo
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()
        
        # Encuentra la segunda aparición de '---\n'
        yaml_end_index = lines.index('---\n', 1)  # Encuentra la segunda aparición de '---\n'
        
        # Inserta "link" antes del segundo '---\n'
        lines.insert(yaml_end_index, 'link\n')
        
        # Escribe de nuevo el contenido en el archivo
        with open(file_path, 'w', encoding='utf-8') as file:
            file.writelines(lines)

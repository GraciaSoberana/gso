---
type: greekwordNT
palabra: δεῖ
frecuencia: 101
traduccion: obligar; ser necesario
morfologia: Verbo regular
strongnt: 1163
clase: 12
link
---
link

δεῖ
